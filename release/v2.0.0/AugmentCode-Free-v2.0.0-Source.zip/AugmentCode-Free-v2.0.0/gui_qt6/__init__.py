"""
PyQt6 GUI Module for AugmentCode-Free
Modern, cross-platform graphical interface implementation.
"""

__version__ = "1.0.6"
__author__ = "AugmentCode-Free Team"
